#include<iostream>
//#include<conio.h>
#include <fstream>
#include <map>
#include<time.h>
#include <vector>
#include <string.h>
#include<stdlib.h>
#include<math.h>

using namespace std;
void kmeans_on_naive(map<long,vector<int> >,int, int,map<int,long> );
int main(int argc,char *argv[])
{
    int exec_time=0;
    map<long,vector<int> > datastore;
    int temp=0;
    ofstream missingscns;

    

    int threshold=1;
    int clustersize=2;
	
	if(argv[1]!=NULL)
	clustersize=(atoi)(argv[1]);
    
	
	


   // cout<<endl<<"Cluster size  "<<clustersize<<endl<<endl<<"Threshold value   "<<threshold<<endl;
    cout<<endl;
    vector<int> attributeholder;
    char buffer[40];
    map<int,long> tempholder;
    int count=0;
    int uni=0;
	
	/*File containing all records, including ok, fraud and unknown records labelled using Naive Bayes algorithm
	For a given dataset, there are total 4 attributes and one class label.
	Two of the attribute values previously had non-numerical values. Thus to ignore that, we replace all non-numeric attribute
	values by 1. Thus eliminating their effect on K-means clustering if any.
	Non-numeric class labels are replaced by numric values to match with implementation datatype
	We map labels from string to integers as follows
	ok    -> 2
	fraud -> 4*/
	ifstream sales_data_input;
    if((argv[2]==NULL) || ((atoi)(argv[2])==0))
	sales_data_input.open("allokfraud_kmeans.txt");
	/*File containing only training records. Labels are already provided with either ok or fraud*/
	else
	{
    sales_data_input.open("training_okf.txt");
	//sales_data_input.open("okfraudmod.txt");
}
    char *second=NULL;
    
	/*Read input file containing labelled records */
	//cout<<"sdfs";
	while(!sales_data_input.eof())
    {
	//cout<<"ssdf"<<endl;
		/*Each individual cell in record is tab delimited*/
	
        sales_data_input.getline(buffer,40);
        char *first=strtok(buffer,"\t");
        second=strtok(NULL,"\t");
        while(second!=NULL)
        {
            int sec=(atoi)(second);
            attributeholder.push_back(sec);
            second=strtok(NULL,"\t");
        }
		
		/*Store record identifier as key in dataset Map and then store subsequent attrobute values
		for that record */
		
        long fir=atol(first);
//cout<<first<<endl;      
	  datastore[fir]=attributeholder;
		
		/*clear the vector attributeholder at the end of each iteration
		Store new attribute values each time for next records*/
//	cout<<attributeholder.size()<<endl;	
        attributeholder.clear();
        tempholder[count++]=fir;
    }
    
    /*Calling K-means clustering routines
    datastore - map which contains all the sales record identifier with their respective attributes
    clustersize - Total number of final clusters to form K=clustersize
    threshold - Parameter to assess diffrence between previous and current centroid positions
    When difference goes below threshold, it meets convergence condition
    */
	
    /*Start time to measure execution time
	track the clock at the end of execution */
	
	exec_time=clock();
   kmeans_on_naive(datastore,clustersize,threshold,tempholder);

    printf("Total Execution time in Seconds %f for Cluster Size %d\n\n",(clock()-(float)exec_time)/1000000,clustersize);
    missingscns.close();
    //getch();
    return 1;
}


void kmeans_on_naive(map<long,vector<int> > datastore,int clustersize,int threshold,map<int,long> tempholder)
{
    map<long,vector<int> >::iterator iter;
    map<int,long>::iterator iter1;
    int count123=0;
    srand((unsigned)time(0));
    vector<long> initcentroids;
    map<int,long> checkdupli;
    int prevalue=0;
    map<long,vector<int> > oldvaluecentroid;
    
	/* Routine to generate initial set of centroids from given data
    K centroids are chosen using C++ rand() function */
    
	while(count123<clustersize)
    {
        int rannumber=rand()%tempholder.size();
        if(checkdupli[rannumber]>-1)
        {
            vector<int> softvector;
            for(int i1=0; i1<datastore[tempholder[rannumber]].size(); i1++)
            {
                softvector.push_back(datastore[tempholder[rannumber]].at(i1));
            }
            initcentroids.push_back(tempholder[rannumber]);
            oldvaluecentroid[tempholder[rannumber]]=softvector;
            count123++;
            softvector.clear();
    
	/* Flag to avoid same centroid being generated twice */
    
			checkdupli[rannumber]=-1;
        }
        else
        {
		
            /* Same centroid generated using rand() function
            again loop back and generate other centroid using
            rand() function*/
			
            continue;
        }
    }
	
    /* Container to hold new centroid and its corresponding members */
    
	map<long,vector<int> > newvaluecentroid;
    vector<int> temp90;
    bool flag=true;
    map<long,vector<int> > indicluster;
    map<long, vector<int> >::iterator it57;
    
	/*Infinite while loop to generate the new set of centroids
    Loop breaks whenever convergence occurs.
    Convergence occurs when there is no change in the values of centroid attributes*/
    
	int iterationcount=0;

    while(1)
    {
        iterationcount++;
        indicluster.clear();
        for(int j=0; j<datastore.size(); j++)
        {
            int cluster=0;
            double minimum=30000;
            double sum;
            vector<int> pointdata=datastore[tempholder[j]];
            for(int centro=0; centro<initcentroids.size(); centro++)
            {
                sum=0.0;
                vector<int> centroiddata=oldvaluecentroid[initcentroids.at(centro)];
     
	 /*Calculate euclidean distance of given point from set of all centroids*/

	 for(int vl=0; vl<pointdata.size(); vl++)
                {
                    sum+=sqrt(pow((pointdata.at(vl)-centroiddata.at(vl)),2));
                }
     
	 /*If distance thus computed is less than distance of previous centroid,
     store it in a minimum variable */

                if(sum<minimum)
                {
                    cluster=initcentroids.at(centro);
                    minimum=sum;
                }
            }
     
	 /*Point is assigned to centroid with minimum euclidean distance */

	 indicluster[cluster].push_back(tempholder[j]);
        }
      
	  /* If no point is assigned to any centroid, store dummy value of zero for that
        centroid. This is to avoid segmentation fault due to access to non existent
        variable */

        for(int centro=0; centro<initcentroids.size(); centro++)
        {
            if(!(indicluster.count(initcentroids.at(centro))))
            {
                indicluster[initcentroids.at(centro)].push_back(0);
            }
        }
	
        map<long,vector<int> >::iterator ite2;
        map<long,vector<int> > indiclusternew;
        
		/*For each value of current centroid, iterate over all its member records.
        Generate new centroid by averaging all attribute values */
        
		for(ite2=indicluster.begin(); ite2!=indicluster.end(); ite2++)
        {
            int *temparr=(int *)calloc(5,sizeof(int));
            vector<int> sumattri;
            for(int j=0; j<(ite2->second).size(); j++)
            {
                int fed=0;
                if((ite2->second).size()==1 && (ite2->second).at(0)==0)
                {
                    break;
                }
                for(int k=0; k<5; k++)
                {
                    temparr[k]=temparr[k]+datastore[(ite2->second).at(j)].at(k);
                }
                fed=0;
            }
            for(int co=0; co<5; co++)
            {
                int finvalue=(temparr[co])/((ite2->second).size());
                sumattri.push_back(finvalue);
            }
            long val = ite2->first;
            
			/*Push new centroid along with its attributes in a
            newvaluecentroid map data structure. These attributes
            are compared against old values of centroid to check
            if convergence occurred */
            
			indiclusternew[val]=sumattri;
            newvaluecentroid[val]=sumattri;
            sumattri.clear();
        }
        map<long,vector<int> >::iterator ittnew=newvaluecentroid.begin();
        map<long,vector<int> >::iterator ittold=oldvaluecentroid.begin();
        int sumall=0;
        
		/*Iterate over every centroid. Check for attribute differences for each attribute.
        Take the absolute sum of these differences*/
        
		while(ittnew!=newvaluecentroid.end() && ittold!=oldvaluecentroid.end())
        {
            long temp60new=ittnew->first;
            long temp60old=ittold->first;
            for(int count12=0; count12<newvaluecentroid[temp60new].size(); count12++)
            {
                sumall+=(oldvaluecentroid[temp60old].at(count12)-newvaluecentroid[temp60new].at(count12));
            }
            ittnew++;
            ittold++;
        }
        cout<<"Absolute value of centroids difference in "<<iterationcount<<" th iteration is "<<abs(sumall)<<endl;
        //cout<<"Iteration Number"
		/* If diffrence between current and old centroid values is less than threshold, then
        we reached the convergence condition. Break out of infinite while loop */
		
        if(abs(sumall)<=threshold)
        {
            break;
        }
        
		/*For the next iteration clear all hashmap values*/
        
		initcentroids.clear();
        oldvaluecentroid.clear();
        
		/*Change current centroids to old centroids for next iteration */
        
		oldvaluecentroid=newvaluecentroid;
        map<long, vector<int> >::iterator itt;
        for(itt=newvaluecentroid.begin(); itt!=newvaluecentroid.end(); itt++)
        {
            long keyval=itt->first;
            initcentroids.push_back(keyval);
        }
        newvaluecentroid.clear();
        flag=false;
    }
	
	/*Section to calculate final true positives and false positives in clusters thus formed*/
	
    int checkvalue=0;
    int four=0;
    int two=0;
    int tp=0;
    int fp=0;
    double ppv=0.0;
    for(it57=indicluster.begin(); it57!=indicluster.end(); it57++)
    {
        four=0;
        two=0;
		
        /*If empty cluster is found with no members assigned to it,
        don't consider it. Go to next centroid */
        
		if((it57->second).size()==1 && (it57->second).at(0)==0)
        {
            continue;
        }
        checkvalue=datastore[it57->first].at(2);
        
		/* Check for majority in each cluster
        if points with class=4 are more than those
        with class=2 then we name that as cluster of class 4
        and vice versa.
        After classification points mismatching with cluster
        label are considered as false positives while those
        matching with label are considered as true positives */
        
		for(int h=0; h<(it57->second).size(); h++)
        {
            if(datastore[(it57->second).at(h)].at(4)==4)
            {
                four++;
            }
            else
            {
                two++;
            }
        }
        
		if(four>=two)
        {
            for(int h=0; h<(it57->second).size(); h++)
            {
                if(datastore[(it57->second).at(h)].at(4)==4)
                {
                    tp++;
                }
                else
                {
                    fp++;
                }
            }
        }
        
		/* Calculate number of True positives and False positives in each cluster */
        
		else
        {
            for(int h=0; h<(it57->second).size(); h++)
            {
                if(datastore[(it57->second).at(h)].at(4)==2)
                {
                    tp++;
                }
                else
                {
                    fp++;
                }
            }
        }
        
		/* Calculate and accumulate Positive predictive value for each cluster
        PPV value is calculated as
        ppv=(tp)/(tp+fp)
        */
        
		ppv+=(tp)/(double)(tp+fp);
        tp=0;
        fp=0;
    }
    
	/* Final average PPV value over k-clusters */
    
	double finalppv=ppv/(double)indicluster.size();
    cout<<endl<<endl<<"Final PPV value for "<<clustersize<<" clusters is "<<finalppv<<endl<<endl;
}
