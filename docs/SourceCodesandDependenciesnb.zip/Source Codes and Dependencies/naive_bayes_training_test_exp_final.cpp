#include<iostream>
#include <fstream>
#include <map>
#include<iomanip>
//#include<conio.h>
#include<time.h>
#include <vector>
#include <string.h>
#include<stdlib.h>
#include<math.h>
#define PI 3.14159265359
#define E 2.71828182846
#define sqrt_pi 2.506628274631
using namespace std;

void naive_bayes(vector< vector<string> >,map<int,string>,int begin_index);
double ratio_final;

/* Author - Jayesh Kawli */

int main()
{
    /* Variables */

    int ppv_time=0;
    int vec_pos=0;
    int vec_overall=0;
    int gt=0;
    vector< vector<string> > sales_data_vec;
    char buffer[40];
    int indi;

    /* Input file containing training records with original class labels of OK or frauds */

    ifstream salesdata("okfraud.txt");

    /* Reading training records from input file */ 

    while(!salesdata.eof())
    {
        indi=0;
        bool isunknown=false;
        vector<int> attributeholder;
        char *indiattri;
        salesdata.getline(buffer,40);
        char *pch = strtok (buffer,"\t");
        vec_pos=0;
        vector<string> temp;
        temp.clear();
        int test=0;
        while(pch!=NULL)
        {
            char temp12[10];
            strcpy(temp12,pch);
            temp.insert(temp.begin()+vec_pos,temp12);
            test++;
            
            /* Check to ignore records with missing values */
            
            if(!strcmp(pch,"NA"))
            {
                pch=0;
                gt++;
                indi=1;
                break;
            }
            vec_pos++;
            
            /* Records are delimited by tab space */
            
            pch=strtok(NULL,"\t");
        }
        if(indi==0)
        {
            sales_data_vec.insert(sales_data_vec.begin()+vec_overall,temp);
            vec_overall++;
        }
        else
        {
            indi=0;
        }
    }

    //cout<<"The Number of records with missing values  "<<gt<<endl;

    int single_block_size =(int)ceil(sales_data_vec.size()/10);
    double last_block_size=(double)(single_block_size+(sales_data_vec.size()%10));
    int data=0;
    map<int,string> label_holder;
    ppv_time=clock();
    int begin1,begin,iter=0;
    
    for(int i=0; i<10; i++)
    {
        begin1=i*(single_block_size);
        iter=0;
        
        /* Store all known values in loabel_holder buffer, replace those values 
        with unkn label and then calculate labels for them */
       
        string vec_label;
        for(int j=(i)*single_block_size; j<=((i+1)*(single_block_size))-1; j++)
        {
            vec_label=sales_data_vec.at(j).at(4);
            sales_data_vec[j][4]="unkn";
            label_holder[iter++]=vec_label;
            
        }
        
        /* Following loop takes care of remaining elements at the last block. 
        Remaining elements are added in vector and passed to naive Bayes algorithm
        for final classification verification */
        
        if(i==9)
        {
            int start_pos=(i+1)*(single_block_size);
            int span=(int)(last_block_size-single_block_size);
             for(int k=start_pos;k<start_pos+span;k++)
             {                             
                    vec_label=sales_data_vec.at(k).at(4);   
                    sales_data_vec[k][4]="unkn";
                    label_holder[iter++]=vec_label;    
             }                   
        }
        
        /*Give values to Naive bayes with test and training dataset to calculate model accuracy*/        
        
        naive_bayes(sales_data_vec,label_holder,begin1);
        begin=0;
        
        /* Replace all unknown values with their original labels
        after one pass. In the next pass, again replace lebels of 
        next block with all unknown and store their true classes in another
        buffer */
        
        for(int j=(i)*single_block_size; j<(i+1)*(single_block_size); j++)
        {
            sales_data_vec[j][4]=label_holder[begin];
            begin++;
        }

        /* Always clear label_holder buffer when used for next round */
        
        label_holder.clear();
    }
    
    /* Gives the statistical measure of algorithm accuracy and performance. 
    Denotes execution time and average PPV value combined of all the
    iterations */
    cout<<endl;
    cout<<endl<<"Total Execution time (In seconds) for PPV "<<(((float)ppv_time/CLOCKS_PER_SEC)*10)<<endl;
    cout<<endl<<"Avergae PPV value using Naive Bayes algorithm for Sales data is:   "<<(ratio_final/10)<<endl;
    cout<<endl<<"Avergae PPV value (in percentage):  "<<(ratio_final*10)<<endl<<endl;
    
    //getch();
    return 1;
}
void naive_bayes(vector< vector<string> > sales_data_vec,map<int,string> training_label,int begin_index)
{
    map<string,int> values_ok;
    map<string,int> values_fraud;
    int temp=0;
    string string1;
    map<int,long> tempholder;
    
    int count=0;
    int uni=0;
    ofstream getoutdata;
   
    int gt=0;

    vector< vector<string> >::iterator it1;
    vector<string>::iterator it2;

    int number_ok=0,number_fraud=0,number_unknown=0;
    int quantity_fraud=0,quantity_ok=0,value_ok=0,value_fraud=0;

    /* Store the count for each value in attribute column 
    salesman and product id for both class labels ok and fraud
    Store the count. And this will further be used to calculate 
    probabilites which will be used to find labels for test data  
    */
    
    for(it1=sales_data_vec.begin(); it1!=sales_data_vec.end(); it1++)
    {
        /* If the record label is ok, then add values of quanity and values
        in appropriate variables this will then be used to calculate normalized
        value for each numerical attributes */
        
        if(!(((*it1).at(4).compare("ok"))))
        {
            quantity_ok+=atoi((*it1).at(2).c_str());
            value_ok+=atoi((*it1).at(3).c_str());
            number_ok++;
        }
        
        /* If the record label is false, then add values of quanity and values
        in appropriate variables this will then be used to calculate normalized
        value for each numerical attributes */
        
        else if(!((((*it1).at(4)).compare("fraud"))))
        {
            quantity_fraud+=atoi((*it1).at(2).c_str());
            value_fraud+=atoi((*it1).at(3).c_str());
            number_fraud++;
        }
        
        /* Unknown Labels. Do nothing */
        
        else
        {
            number_unknown++;
        }
    }

    /* Calculate mean values in each of the quantity and values columns for
    both ok and fraud labels. This is to calculate normalized values of 
    numerical attributes and evaluate their probabilities for test/unknown data */

    double mean_quantity_fraud=(quantity_fraud/number_fraud);
    double mean_quantity_ok=(quantity_ok/number_ok);
    double mean_value_ok=(value_ok/number_ok);
    double mean_value_fraud=(value_fraud/number_fraud);
    double var_quantity_fraud=0,var_quantity_ok=0,var_value_ok=0,var_value_fraud=0;
   
    /* Once caluclate mean values, calculate variance using standard variance formula */
   
    for(it1=sales_data_vec.begin(); it1!=sales_data_vec.end(); it1++)
    {
        if(!(((*it1).at(4).compare("ok"))))
        {       
            var_quantity_ok+=pow((atoi((*it1).at(2).c_str())-mean_quantity_ok),2);
            var_value_ok+=pow((atoi((*it1).at(3).c_str())-mean_value_ok),2);
        }
        else if(!((((*it1).at(4)).compare("fraud"))))
        {    
            var_quantity_fraud+=pow((atoi((*it1).at(2).c_str())-mean_quantity_fraud),2);
            var_value_fraud+=pow((atoi((*it1).at(3).c_str())-mean_value_fraud),2);
        }
    }
   
    /* Divide by number of samples it might be n or (n-1) */
   
    var_quantity_fraud=(double)(var_quantity_fraud/number_fraud);
    var_quantity_ok=(double)(var_quantity_ok/number_ok);
    var_value_ok=(double)(var_value_ok/number_ok);
    var_value_fraud=(double)(var_value_fraud/number_fraud);

    /* Calculate standard deviation */

    double std_quantity_fraud=sqrt(var_quantity_fraud);
    double std_quantity_ok=sqrt(var_quantity_ok);
    double std_value_ok=sqrt(var_value_ok);
    double std_value_fraud=sqrt(var_value_fraud);

    double const1_quantity_fraud=(double)(1/(sqrt_pi*std_quantity_fraud));
    double const1_quantity_ok=(double)(1/(sqrt_pi*std_quantity_ok));
    double const1_value_ok=(double)(1/(sqrt_pi*std_value_ok));
    double const1_value_fraud=(double)(1/(sqrt_pi*std_value_fraud));

    double const2_quantity_fraud=(double)pow(E,-(double)(1/(2*var_quantity_fraud)));
    double const2_quantity_ok=(double)pow(E,-(double)(1/(2*var_quantity_ok)));
    double const2_value_ok=(double)pow(E,-(double)(1/(2*var_value_ok)));
    double const2_value_fraud=(double)pow(E,-(double)(1/(2*var_value_fraud)));

    for(it1=sales_data_vec.begin(); it1!=sales_data_vec.end(); it1++)
    {
        for(int i=0; i<2; i++)
        {
            if(!((*it1).at(4).compare("unkn")))
            {
                break;
            }
            else if(!((*it1).at(4).compare("fraud")))
            {
                if(values_fraud.count((*it1).at(i))>0)
                {
                    values_fraud[(*it1).at(i)]++;
                }
                else
                {
                    values_fraud[(*it1).at(i)]=1;
                }
            }
            else if(!((*it1).at(4).compare("ok")))
            {
                if(values_ok.count((*it1).at(i))>0)
                {
                    values_ok[(*it1).at(i)]++;
                }
                else
                {
                    values_ok[((*it1).at(i))]=1;
                }
            }
        }
    }

    map<string,int>::iterator it3;

    /*For each unknown records, calculate the probability of it being either ok 
    or fraud. Now based upon these probability values */
    
    double prior_estimate_fraud;
    double prior_estimate_ok;
    
    /* Tested with different values of prior estimate. There was little difference 
    in final estimation of class labels for unknown data */
    
    prior_estimate_fraud=0.5;
    prior_estimate_ok=0.5;
    double temp_value_fraud=0,temp_quantity_fraud=0,temp_value_ok=0,temp_quantity_ok=0;
    
    /* Sample size determines, size of dummy sample assumed to be having that class label which
    is not found is any of the test dataset. This is assumed to be 5 on experimental calculation */
    
    double sample_size=5;
    int iit=0;
    int tr=0,fal=0;
    int tty=0;
    
    for(it1=sales_data_vec.begin(); it1!=sales_data_vec.end(); it1++)
    {
        tty++;
        if(!((*it1).at(4).compare("unkn")))
        {
            temp_value_ok=pow((atoi((*it1).at(3).c_str())-mean_value_ok),2);
            temp_quantity_ok=pow((atoi((*it1).at(2).c_str())-mean_quantity_ok),2);
            temp_value_ok=(const1_value_ok)*pow((const2_value_ok),temp_value_ok);
            temp_quantity_ok=(const1_quantity_ok)*pow((const2_quantity_ok),temp_quantity_ok);
            double ok=(double)((double)(number_ok)/(number_ok+number_fraud)*((values_ok[(*it1).at(0)]+(sample_size*prior_estimate_ok))/(double)(number_ok+sample_size))*((values_ok[(*it1).at(1)]+(sample_size*prior_estimate_ok))/(double)(number_ok+sample_size))*temp_quantity_ok*temp_value_ok);

            temp_value_fraud=pow((atoi((*it1).at(3).c_str())-mean_value_fraud),2);
            temp_quantity_fraud=pow((atoi((*it1).at(2).c_str())-mean_quantity_fraud),2);
            temp_value_fraud=(const1_value_fraud)*pow((const2_value_fraud),temp_value_fraud);
            temp_quantity_fraud=(const1_quantity_fraud)*pow((const2_quantity_fraud),temp_quantity_fraud);

            double fraud=(double)((double)(number_fraud)/(number_ok+number_fraud)*((values_fraud[(*it1).at(0)]+(sample_size*prior_estimate_fraud))/(double)(number_fraud+sample_size))*((values_fraud[(*it1).at(1)]+(sample_size*prior_estimate_fraud))/(double)(number_fraud+sample_size))*temp_quantity_fraud*temp_value_fraud);

            int i=0;

            string final_res;
            
            /* This is actual testing with known and evaluated data
            When algorithm tells it is fraud and it matches with actual 
            class, it increments true positive variable, else increments
            false positive label */
            
            if(ok<fraud)
            {
                if(training_label[iit].compare("fraud"))
                {
                    fal++;
                }
                else
                {
                    tr++;
                }
            }
            else if(ok>=fraud)
            {
                if(training_label[iit].compare("ok"))
                {
                    fal++;
                }
                else
                {
                    tr++;
                }
            }
            getoutdata<<endl;
            iit++;
        }
    }
    
    /* Now we have count of false and true positives. 
    Calculate PPV values using standard formula  */
    
    double ratio=(double)(tr)/(tr+fal);
    ratio_final+=ratio;
	cout<<setw(10);
    cout<<ratio<<"  Calculating Ratio.......iterating in loop...."<<endl;
	//cout<<"**********************************************\n";
}
