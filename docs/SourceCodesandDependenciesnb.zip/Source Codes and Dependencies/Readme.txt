CSCI-B 565 DATA MINING - Homework 3

Submitted on 11/26/2012

Details of submission - Assignment and source code

*****Project Report and Assignment*****


DMHW3Fall2012.pdf (In .PDF format)

DMHW3Fall2012.tex (In .tex format)


*******************Source code files*****************


1. naive_bayes_only_final.cpp

Naive Bayes algorithm takes input file containing records 
with both ok/fraud and unknown labels. 

Classifies unknown records to appropriate class as either
ok/fraud

----------------------------------------------------------

2. naive_bayes_training_test_exp_final.cpp

Naive Bayes algorithm and calculation of PPV value

This program is basically used to assess the accuracy
of model built using training records.

PPV is calculated using 10-fold cross validation approach

----------------------------------------------------------

3. kmean_bayes.cpp

K-means clustering algorithm for clustering classified data
into clusters

Takes the input as file which contains both training as well as
test records. Class labels for test dataset are already calculated
using Naive Bayes approach

Performs clustering on both only on training dataset and cumulative
dataset which contains test and training dataset as well.

--------------------------------------------------------- 

4. randomforest.r

R program which Uses randomForest package to classify unknown records

Assessed the classification performance of randomForest package with that
obtained using Naive Bayes approach

----------------------------------------------------------




