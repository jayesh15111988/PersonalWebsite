library("randomForest")
salesdata<-read.table('traintemp1.txt',col.names=c("salesmanid","productid","quantity","value","label"))
train=salesdata[c(1554:15535),]
test<-salesdata[c(1:1553),]
ranfor<-randomForest(label ~ quantity + value,data=train,importance=TRUE,do.trace=100)
predication<-predict(ranfor,test)
final_res<-table(observed=test[,'label'],predict=prediction)
prop.table(final_res,1)


