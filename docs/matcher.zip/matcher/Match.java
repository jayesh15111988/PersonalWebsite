/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
/**
 *
 * Example referred from:
 * http://www.nrmp.org/res_match/about_res/algorithms.html
 * @author JK029081
 */

package com.cerner.newdevelopment.matcher;

import java.io.*;
import java.util.*;

/* Main Class Match to perform matches between Medical Schools and Students 
 Class Match stores all the major information about students and schools. It is
 assumed that order is in chronological order of preference*/

public class Match {

    private String p1;
    private String p2;
    private int value;

    Match() {
    }

    /* Writing List of preferrer and preferred in the output file */
    public void writeoutput(ArrayList<ArrayList<String>> answer, String filename) {
        try {
            File file = new File(filename);
            BufferedWriter out = new BufferedWriter(new FileWriter(file));

            for (int i = 0; i < answer.size(); i++) {
                out.write(answer.get(i).get(0) + ", " + answer.get(i).get(1));
                out.write("\n");
            }

            if (out != null) {
                out.flush();
                out.close();
            }

        } catch (IOException e) {
            e.printStackTrace();
        }


    }

    /* Function which takes input as Object and converts it into Hashmap.
     * Key represent preferee values and Value is an arraylist mentioning the value preferred by preferee
     */
    LinkedHashMap<String, ArrayList<String>> convertobjtoarray(ArrayList<Match> objarray) {

        // String initial = objarray.get(0).getp1();

        /* For each school check if it exists. In case of non-existent school, insert school along with
         * the names of students it prefers
         */

        LinkedHashMap<String, ArrayList<String>> data = new LinkedHashMap<String, ArrayList<String>>();
        for (int i = 0; i < objarray.size(); i++) {
            if (!data.containsKey(objarray.get(i).getp1())) {
                ArrayList<String> temp = new ArrayList<String>();
                temp.add(objarray.get(i).getp2());
                data.put(objarray.get(i).getp1(), temp);

            } else {
                ArrayList<String> temp1 = data.get(objarray.get(i).getp1());

                temp1.add(objarray.get(i).getp2());
                data.put(objarray.get(i).getp1(), temp1);
            }


        }

        /* for (Map.Entry<String, ArrayList<String>> entry : data.entrySet()) {
         String key = entry.getKey();
         int value = entry.getValue().size();

         }*/
        return data;
    }

    /* Routine to perform match between two individuals how close they are */
    ArrayList<ArrayList<String>> checkMatchforAll(LinkedHashMap<String, ArrayList<String>> preferrer, LinkedHashMap<String, ArrayList<String>> preferred) {

        LinkedHashMap<String, Integer> initcount = new LinkedHashMap<String, Integer>();
        LinkedHashMap<String, Integer> actualcount = new LinkedHashMap<String, Integer>();
/*
        for (Map.Entry<String, ArrayList<String>> entry : preferred.entrySet()) {
            //System.out.println(entry.getKey());
            for (int i = 0; i < entry.getValue().size(); i++) {
                    System.out.print(entry.getValue().get(i));
                //  System.out.print("  ");
            }
            //  System.out.println("*******************");
        }*/
        Map<String, Integer> preferrer_store = new HashMap<String, Integer>();
        for (Map.Entry<String, ArrayList<String>> entry : preferred.entrySet()) {
            initcount.put(entry.getKey(), 0);
           
            //actualcount.put(entry.getKey(), entry.getValue().size());
            actualcount.put(entry.getKey(), 2);
            //System.out.println(entry.getValue().size());
        }

        ArrayList<ArrayList<String>> result = new ArrayList<ArrayList<String>>();

        for (Map.Entry<String, ArrayList<String>> entry : preferrer.entrySet()) {


            String key = entry.getKey();
            //System.out.println("key..." + key);
            int value = entry.getValue().size();
//            System.out.println(value+"haaa");
            for (int i = 0; i < value; i++) {

                //Bug Causing exception when student name exists in the school preference list, but it has selected no school 
                //Check if student is encountered for that college but student never gave preference for it
                //Don't assign student to that college

                /*            if (!preferred.get(entry.getValue().get(i)).contains(key)) {
                 continue;
                 }*/

                //Else if Student has mentioned that college in his preferences list then continue



                //Check if Student does exist in preferences list.
                //If not go on for next student

                if (!preferred.containsKey(entry.getValue().get(i))) {
                    //ArrayList<String> finalval=new ArrayList<String>();
                    //Student did not present list of preferable colleges. gets Nothing
                    // System.out.println(entry.getValue().get(i));
                    continue;


                } //Student is present in preferred list
                else if (preferred.containsKey(entry.getValue().get(i))) {
                    ArrayList<String> temp2 = preferred.get(entry.getValue().get(i));
                    

                    //key is the name of college


                    //Check if School exists on student's preference
                    if (temp2.contains(key)) {

                        ArrayList<String> beforeadd = new ArrayList<String>();

                        beforeadd.add(key);
                        beforeadd.add(entry.getValue().get(i));

                        //System.out.println(key+" "+entry.getValue().get(i));
                        //result.put(key,entry.getValue().get(i));



                        //if(initcount.get(key)>=actualcount.get(key))

                        //If quota for that school if already full
                        //Then iterate over students list and remove student who has least preference for that school
//System.out.println(actualcount.get(entry.getValue().get(i))+"this is"+initcount.get(entry.getValue().get(i)));
                        //System.out.println(actualcount.get(entry.getValue().get(i)) + "" + initcount.get(entry.getValue().get(i)));
                        if (initcount.get(entry.getValue().get(i)) >= actualcount.get(entry.getValue().get(i))) {
//System.out.println("gotcha");
                            //  System.out.println(actualcount.get(entry.getValue().get(i))+"wwowow"+initcount.get(entry.getValue().get(i)));
                            ArrayList<ArrayList<String>> result_data = new ArrayList<ArrayList<String>>();
                            
//result_data=null;
                            

                            for (int cou = 0; cou < result.size(); cou++) {
                                //ArrayList<String> tempo = new ArrayList<String>();
                                //ArrayList<String> tempo1 = new ArrayList<String>();
                                //tempo = result.get(i);
                                //tempo1=result.get(i+1);
                                if (result.get(cou).get(1) != null && result.get(cou).get(1).equals(entry.getValue().get(i))) {
                            //        System.out.print(result.get(cou).get(0) + " && ");
                                    ArrayList<String> tem = new ArrayList<String>();
                                    tem.add(result.get(cou).get(0));
                                    tem.add(new Integer(cou).toString());
                                    result_data.add(tem);
                                }
                            }
                            ArrayList<String> temp = new ArrayList<String>();
                            //System.out.println("****");
                            for (int ii = 0; ii < result_data.size() - 1; ii++) {
//System.out.println(entry.getValue().get(i)+"whattt?  "+key+"  "+tempo.get(0));
                                if (preferred.get(entry.getValue().get(i)).indexOf(result_data.get(ii).get(0)) < preferred.get(entry.getValue().get(i)).indexOf(result_data.get(ii + 1).get(0))
                                        && preferred.get(entry.getValue().get(i)).indexOf(result_data.get(ii).get(0)) >= 0 && preferred.get(entry.getValue().get(i)).indexOf(result_data.get(ii + 1).get(0)) >= 0) {
//result_old=result_data.get(ii+1);
                                    temp = result_data.get(ii + 1);

                                } else {
                                    //No candidate with preference more than already present found
                                    //          result_old=result_data.get(ii);   
                                    //                     continue;
                                    temp = result_data.get(ii);

                                }
                            }
                            if (preferred.get(entry.getValue().get(i)).indexOf(temp.get(0)) > preferred.get(entry.getValue().get(i)).indexOf(key)
                                    && preferred.get(entry.getValue().get(i)).indexOf(temp.get(0)) >= 0 && preferred.get(entry.getValue().get(i)).indexOf((key)) >= 0) {
                                System.out.println("Removing student "+temp.get(0) + " from School " + entry.getValue().get(i));
                                //System.out.println(key + " adding ");
                                //A candidate with more strong rating for college found

                                //   System.out.println(tempo.get(0)+"Removes");

                                /* Remove the student which has less preference for current School */
                                //                                  System.out.println(tempo+"removed");

                                //System.out.println("Removed " + temp.get(0) + " and " + entry.getValue().get(i));
                                result.remove(Integer.parseInt(temp.get(1)));
                                initcount.put(entry.getValue().get(i), initcount.get(entry.getValue().get(i)) - 1);
                                if (preferrer_store.containsKey(temp.get(0))) {

                                    preferrer_store.put(temp.get(0), preferrer_store.get(temp.get(0)) - 1);
                                } else {
                                    //preferrer_store.put(temp.get(0),0);
                                }
                                //System.out.println(entry.getValue().get(i) + " old count " + initcount.get(entry.getValue().get(i)));
                                ArrayList<String> temp3 = new ArrayList<String>();
                                temp3.add(key);
                                temp3.add(entry.getValue().get(i));
                                result.add(temp3);
                                initcount.put(entry.getValue().get(i), initcount.get(entry.getValue().get(i)) + 1);
                                if (preferrer_store.containsKey(key)) {

                                    preferrer_store.put(key, preferrer_store.get(key) + 1);
                                } else {
                                    preferrer_store.put(key, 1);
                                }
                                //System.out.println(entry.getValue().get(i) + " current count " + initcount.get(entry.getValue().get(i)));
                                System.out.println("Adding student " + key + " to School " + entry.getValue().get(i));
                                break;
                            }




                        } //When no obstruction is encountered, simply insert data into the result
                        //This result is tentative in the sense that high priority person might remove
                        //Low priority person
                        else {
                            //System.out.print(key+"key");
                            //System.out.println(beforeadd.get(1));
                            if (!preferrer_store.containsKey(beforeadd.get(0))) {
                                preferrer_store.put(beforeadd.get(0), 1);
                            } else {
                                preferrer_store.put(beforeadd.get(0), preferrer_store.get(beforeadd.get(0)) + 1);

                            }
                            result.add(beforeadd);
                            System.out.println("Adding student " + beforeadd.get(0) + " to School (Directly no overflow) " + beforeadd.get(1));
                            /*for (Map.Entry<String, Integer> entry1 : initcount.entrySet()) {
//System.out.println(entry1.getKey()+"*** "+entry1.getValue());
                            }*/
                            initcount.put(beforeadd.get(1), initcount.get(beforeadd.get(1)) + 1);
                            /*for (Map.Entry<String, Integer> entry2 : initcount.entrySet()) {
//System.out.println(entry2.getKey()+"^^^ "+entry2.getValue());
                            }*/

                        }



                    } //No student record found in preferred list, go on for next record
                    else {
                        continue;
                    }


                }
                //Condition to check if all records are processed successfully
                //There is chance that some records might be tentative and not yet final

                /*  boolean flag = false;
                 for (Map.Entry<String, Integer> entry1 : initcount.entrySet()) {

                 String hospitalname = entry1.getKey();
                 int count = entry1.getValue();
                 if (preferrer.get(hospitalname).size() != count) {
                 flag = true;
                 //break;
                 }


                 }*/

                /*       if (flag) {

                 continue;
                 } else {
                 break;
                 }*/

            }



        }


        //This loop helps in the scenario where No student has given priority to that college
        //But that school still exists. Or the student to whom this school prioratizes did never
        //put the school on its priority list

        for (Map.Entry<String, Integer> entry : preferrer_store.entrySet()) {
            if (entry.getValue() == 0) {
                ArrayList<String> finalVal = new ArrayList<String>();
                finalVal.add(entry.getKey());
                finalVal.add(" ");
                System.out.println("Adding student "+entry.getKey()+" With no selection "+entry.getValue());
                result.add(finalVal);
            }
        }






System.out.println("List of Students and their matching colleges (Note that some of the students are still unmatched)");

        for (int i = 0; i < result.size(); i++) {
            System.out.println("Student "+result.get(i).get(0) + " ----- School " + result.get(i).get(1));


        }
        return result;
    }

    ArrayList<ArrayList<String>> checkMatch(ArrayList<Match> preferrer, ArrayList<Match> preferred) {
        /* Routines to convert object representation in the HashMap */
        LinkedHashMap<String, ArrayList<String>> objtoarry1 = convertobjtoarray(preferrer);
        //System.out.println("***************************");
        LinkedHashMap<String, ArrayList<String>> objtoarry2 = convertobjtoarray(preferred);


        return checkMatchforAll(objtoarry1, objtoarry2);


        // return null;     

    }

    ArrayList<Match> readfile(String filename) {
        ArrayList<Match> ar = new ArrayList<Match>();
        BufferedReader br = null;

        try {

            String CurrentLine;

            br = new BufferedReader(new FileReader(filename));

            while ((CurrentLine = br.readLine()) != null) {
                String[] items = CurrentLine.split(",");
                Match j1 = new Match(items[0].trim(), items[1].trim(), Integer.parseInt(items[2].trim()));
                ar.add(j1);

            }

        } catch (IOException e) {
            e.printStackTrace();
        }

        return ar;
    }

    Match(String p11, String p21, int value1) {

        p1 = p11;
        p2 = p21;
        value = value1;
    }

    public String getp1() {

        return p1;

    }

    public String getp2() {

        return p2;

    }

    public int getvalue() {

        return value;

    }

    public static void main(String[] args) {

        /*         String preferrer=args[0];
         String preferred=args[1];
         String outputfilename=args[2];
         */
        String preferrer = "C:\\Users\\JK029081\\Documents\\NetBeansProjects\\JavaLibrary1\\src\\com\\cerner\\newdevelopment\\matcher\\input3.csv";
        String preferred = "C:\\Users\\JK029081\\Documents\\NetBeansProjects\\JavaLibrary1\\src\\com\\cerner\\newdevelopment\\matcher\\input4.csv";
        String outputfilename = "C:\\Users\\JK029081\\Documents\\NetBeansProjects\\JavaLibrary1\\src\\com\\cerner\\newdevelopment\\matcher\\output.csv";

        Match j1 = new Match();
        //String outputfilename=output;
        ArrayList<Match> file1 = j1.readfile(preferrer);
        ArrayList<Match> file2 = j1.readfile(preferred);
        //System.out.println(file1.size());
        //System.out.println(file2.size());

        ArrayList<ArrayList<String>> answer = j1.checkMatch(file1, file2);


        j1.writeoutput(answer, outputfilename);

    }
}
